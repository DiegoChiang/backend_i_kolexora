console.log('Vista de carrito cargada');
