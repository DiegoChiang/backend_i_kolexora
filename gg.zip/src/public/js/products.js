const detailSection = document.querySelector('.detail');
const addToCartButton = document.querySelector('#addToCartButton');
const cartIdInput = document.querySelector('#cartId');
const cartMessage = document.querySelector('#cartMessage');

if (addToCartButton && detailSection) {
  addToCartButton.addEventListener('click', async () => {
    const productId = detailSection.dataset.productId;
    const cartId = cartIdInput.value.trim();

    if (!cartId) {
      cartMessage.textContent = 'Debes ingresar un ID de carrito.';
      return;
    }

    try {
      const response = await fetch(`/api/carts/${cartId}/products/${productId}`, {
        method: 'POST'
      });

      const data = await response.json();

      if (!response.ok) {
        cartMessage.textContent = data.message || 'No se pudo agregar el producto.';
        return;
      }

      cartMessage.textContent = 'Producto agregado al carrito correctamente.';
    } catch (error) {
      cartMessage.textContent = 'Error al conectar con el servidor.';
    }
  });
}
